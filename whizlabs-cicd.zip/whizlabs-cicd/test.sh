set -e

echo "go custom test $@"

go test .